"""
LuxeForge Studio

Corner Builder
"""

from __future__ import annotations

from ..path import Path
from ..point import Point


class CornerBuilder:
    """
    Utility class responsible for adding rounded
    corners to a Path.

    The actual arc generation is delegated to
    Path.arc_to().
    """

    @staticmethod
    def top_left(
        path: Path,
        center: Point,
        radius: float,
        segments: int = 8,
    ) -> None:
        """
        Adds a top-left corner.
        """

        path.arc_to(
            center=center,
            radius=radius,
            start_angle=180,
            end_angle=90,
            segments=segments,
        )

    @staticmethod
    def top_right(
        path: Path,
        center: Point,
        radius: float,
        segments: int = 8,
    ) -> None:
        """
        Adds a top-right corner.
        """

        path.arc_to(
            center=center,
            radius=radius,
            start_angle=90,
            end_angle=0,
            segments=segments,
        )

    @staticmethod
    def bottom_right(
        path: Path,
        center: Point,
        radius: float,
        segments: int = 8,
    ) -> None:
        """
        Adds a bottom-right corner.
        """

        path.arc_to(
            center=center,
            radius=radius,
            start_angle=0,
            end_angle=-90,
            segments=segments,
        )

    @staticmethod
    def bottom_left(
        path: Path,
        center: Point,
        radius: float,
        segments: int = 8,
    ) -> None:
        """
        Adds a bottom-left corner.
        """

        path.arc_to(
            center=center,
            radius=radius,
            start_angle=-90,
            end_angle=-180,
            segments=segments,
        )